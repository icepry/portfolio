﻿namespace GSB
{
    partial class FrmVisiteMaj
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnModifie = new System.Windows.Forms.Button();
            this.dtpDate = new System.Windows.Forms.DateTimePicker();
            this.dgvVisitesMaj = new System.Windows.Forms.DataGridView();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvVisitesMaj)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitre
            // 
            this.lblTitre.Size = new System.Drawing.Size(800, 64);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnModifie);
            this.panel2.Controls.Add(this.dtpDate);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(169, 93);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(631, 320);
            this.panel2.TabIndex = 13;
            // 
            // btnModifie
            // 
            this.btnModifie.Location = new System.Drawing.Point(275, 247);
            this.btnModifie.Name = "btnModifie";
            this.btnModifie.Size = new System.Drawing.Size(75, 23);
            this.btnModifie.TabIndex = 1;
            this.btnModifie.Text = "Modifier";
            this.btnModifie.UseVisualStyleBackColor = true;
            // 
            // dtpDate
            // 
            this.dtpDate.Location = new System.Drawing.Point(214, 195);
            this.dtpDate.Name = "dtpDate";
            this.dtpDate.Size = new System.Drawing.Size(200, 20);
            this.dtpDate.TabIndex = 0;
            // 
            // dgvVisitesMaj
            // 
            this.dgvVisitesMaj.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvVisitesMaj.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvVisitesMaj.Location = new System.Drawing.Point(0, 93);
            this.dgvVisitesMaj.Name = "dgvVisitesMaj";
            this.dgvVisitesMaj.Size = new System.Drawing.Size(169, 320);
            this.dgvVisitesMaj.TabIndex = 14;
            // 
            // FrmVisiteMaj
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dgvVisitesMaj);
            this.Controls.Add(this.panel2);
            this.Name = "FrmVisiteMaj";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.FrmVisiteMaj_Load);
            this.Controls.SetChildIndex(this.lblTitre, 0);
            this.Controls.SetChildIndex(this.panel2, 0);
            this.Controls.SetChildIndex(this.dgvVisitesMaj, 0);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvVisitesMaj)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnModifie;
        private System.Windows.Forms.DateTimePicker dtpDate;
        private System.Windows.Forms.DataGridView dgvVisitesMaj;
    }
}