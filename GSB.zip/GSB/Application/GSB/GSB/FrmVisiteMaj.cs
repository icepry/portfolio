﻿using lesClasses;
using Mysqlx.Crud;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GSB
{
    public partial class FrmVisiteMaj : FrmBase
    {
        public FrmVisiteMaj()
        {
            InitializeComponent();
        }

        #region procédures événementielles

        private void FrmVisiteMaj_Load(object sender, EventArgs e)
        {
            parametrerComposant();
        }

        #endregion



        #region méthodes
        private void parametrerComposant()
        {
            this.lblTitre.Text = "Modification de la planification d'un rendez-vous";
            parametrerDate();
            parametrerDgv(dgvVisitesMaj);
            remplirdgvVisitesMaj();
        }


        private DateTime dateRendezVous;
        private void parametrerDate()
        {
            // Définition des limites MinDate et MaxDate
            DateTime dateMin = DateTime.Now.AddHours(2).AddMinutes(-DateTime.Now.Minute);
            if (dateMin.Hour >= 19) dateMin = DateTime.Today.AddDays(1).AddHours(8);
            if (dateMin.DayOfWeek == DayOfWeek.Sunday) dateMin = DateTime.Today.AddDays(1).AddHours(8);

            DateTime dateMax = DateTime.Today.AddDays(60).AddHours(19);

            // Appliquer les contraintes au DateTimePicker
            dtpDate.MinDate = dateMin;
            dtpDate.MaxDate = dateMax;

            // Vérifier si la date actuelle du rendez-vous est toujours valide
            if (dateRendezVous < dateMin)
            {
                dtpDate.Value = dateMin; // Forcer la nouvelle date minimale si l'ancienne date est invalide
            }
            else if (dateRendezVous > dateMax)
            {
                dtpDate.Value = dateMax; // Forcer la nouvelle date maximale si l'ancienne date est invalide
            }
            else
            {
                dtpDate.Value = dateRendezVous; // Conserver la date actuelle si elle est valide
            }

            // Mise en forme de la date
            dtpDate.CustomFormat = "dd/MM/yyyy HH:mm";
            dtpDate.Format = DateTimePickerFormat.Custom;
        }

        private void parametrerDgv(DataGridView dgv)
        {
            #region paramètrage concernant le datagridview dans son ensemble

            // Accessibilité (doit être sur true si on veut pouvoir utiliser les barres de défilement)
            dgv.Enabled = true;

            // style de bordure
            dgv.BorderStyle = BorderStyle.FixedSingle;

            // couleur de fond 
            dgv.BackgroundColor = Color.White;

            // couleur de texte  
            dgv.ForeColor = Color.Black;

            // police de caractères par défaut
            dgv.DefaultCellStyle.Font = new Font("Georgia", 11);

            // mode de sélection dans le composant : FullRowSelect, CellSelect ...
            dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            // sélection multiple 
            dgv.MultiSelect = false;

            // l'utilisateur peut-il ajouter ou supprimer des lignes ?
            dgv.AllowUserToDeleteRows = false;
            dgv.AllowUserToAddRows = false;

            // L'utilisateur peut-il modifier le contenu des cellules ou est-elle réservée à la programmation ?
            dgv.EditMode = DataGridViewEditMode.EditProgrammatically;

            // l'utilisateur peut-il redimensionner les colonnes et les lignes ?
            dgv.AllowUserToResizeColumns = false;
            dgv.AllowUserToResizeRows = false;

            // l'utilisateur peut-il modifier l'ordre des colonnes ?
            dgv.AllowUserToOrderColumns = false;

            // le composant accepte t'il le 'déposer' dans un Glisser - Déposer ?
            dgv.AllowDrop = false;


            #endregion

            #region paramètrage concernant la ligne d'entête 

            // visibilité
            dgv.ColumnHeadersVisible = true;

            // bordure
            dgv.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;

            // style  [à adapter] (ici : noir sur fond transparent sans mise en évidence de la sélection)
            dgv.EnableHeadersVisualStyles = false;
            DataGridViewCellStyle style = dgv.ColumnHeadersDefaultCellStyle;
            style.BackColor = Color.WhiteSmoke;
            style.ForeColor = Color.Black;
            style.SelectionBackColor = Color.WhiteSmoke;    // même couleur que backColor pour ne pas mettre en évidence la colonne sélectionnée
            style.SelectionForeColor = Color.Black;
            style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            style.Font = new Font("Georgia", 12, FontStyle.Bold);


            // hauteur 
            dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dgv.ColumnHeadersHeight = 40;

            #endregion

            #region paramètrage concernant l'entête de ligne (la colonne d'entête ou le sélecteur)

            // visible 
            dgv.RowHeadersVisible = false;

            // style de bordure  
            dgv.RowHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;


            #endregion

            #region paramètrage au niveau des lignes

            // Hauteur 
            dgv.RowTemplate.Height = 30;

            #endregion

            #region paramètrage au niveau des cellules

            // style de bordure 
            dgv.CellBorderStyle = DataGridViewCellBorderStyle.None;

            // couleur de fond, ne pas utiliser transparent car la couleur de la ligne sélectionnée restera après sélection
            dgv.RowsDefaultCellStyle.BackColor = Color.White;

            // Couleur alternative appliquée une ligne sur deux
            // unDgv.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(255, 238, 238, 238);

            #endregion

            #region paramètrage au niveau de la zone sélectionnée

            // couleur de fond mettre la même que les cellules si on ne veut pas mettre la zone en évidence 
            dgv.RowsDefaultCellStyle.SelectionBackColor = System.Drawing.Color.White;

            // couleur du texte
            dgv.RowsDefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;

            #endregion

            #region paramètrage des colonnes

            // Largeur : à contrôler avec la largeur des colonnes si elle est définie
            dgv.Width = 700;

            // Dimensionner la hauteur du DataGridview en fonction du nombre de lignes
            // à faire ici si le composant n'est pas dynamique

            // Nombre de colonne sans compter les colonnes ajoutées par la méthode Add
            dgv.ColumnCount = 4;

            // faut-il ajuster automatiquement la taille des colonnes par un ajustement proportionnel à la largeur totale (commenter la ligne si non)
            dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            // description de chaque colonne  [partie à personnaliser] : visibilité, largeur, alignement cellule et entête si ellene correspond pas à la valeur par défaut
            dgv.Columns[0].HeaderText = "programmée le";
            dgv.Columns[0].Name = "Date";
            dgv.Columns[0].Width = 200;
            dgv.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;

            dgv.Columns[1].HeaderText = "à";
            dgv.Columns[1].Name = "Heure";
            dgv.Columns[1].Width = 50;
            dgv.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgv.Columns[1].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

            dgv.Columns[2].HeaderText = "sur";
            dgv.Columns[2].Name = "Lieu";
            dgv.Columns[2].Width = 200;
            dgv.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;

            dgv.Columns[3].HeaderText = "chez";
            dgv.Columns[3].Name = "Praticien";
            dgv.Columns[3].Width = 250;
            dgv.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;

            // faut-il désactiver le tri sur toutes les colonnes ? (commenter les lignes si non)
            for (int i = 0; i < dgv.ColumnCount; i++)
                dgv.Columns[i].SortMode = DataGridViewColumnSortMode.NotSortable;

            #endregion
        }


        // Remplir le dgvVisitesMaj

        private void remplirdgvVisitesMaj()
        {
            // récupérer les rendez-vous
            List<Visite> lesRendezVous = Globale.mesVisites.FindAll(x => x.Bilan is null);

            // vider le datagridView
            dgvVisitesMaj.Rows.Clear();

            // Parcourir ces visites pour les ajouter dans le datagridview
            TextInfo ti = CultureInfo.CurrentCulture.TextInfo;
            foreach (Visite uneVisite in lesRendezVous)
            {
                // mise en forme de la ville 
                string ville = ti.ToTitleCase(uneVisite.LePraticien.Ville.ToLower());
                dgvVisitesMaj.Rows.Add(uneVisite.DateEtHeure.ToLongDateString(), uneVisite.DateEtHeure.ToShortTimeString(), ville, uneVisite.LePraticien.NomPrenom);
            }
        }




    }
}
#endregion