drop database if exists gsb;

create database gsb character set utf8 collate utf8_general_ci;
use gsb;

SET default_storage_engine = InnoDb;

create table departement  (
    code varchar(3) primary key,
    nom  varchar(50) not null unique
);

create table ville (
    id int auto_increment primary key,
	idDepartement varchar(3),
	idCommune char(5),
	nom varchar(75),
	codePostal char(5)
);

create table famille
(
    id      varchar(3) primary key,
    libelle varchar(80) not null
);

create table medicament
(
    id               varchar(10) PRIMARY KEY,
    nom              varchar(25)  not null,
    composition      varchar(255) not null,
    effets           varchar(255),
    contreIndication varchar(255),
    idFamille        varchar(3)   not null references famille
);

create table specialite
(
    id      varchar(5) PRIMARY KEY,
    libelle varchar(150) not null
);

create table typePraticien
(
    id      varchar(3) PRIMARY KEY,
    libelle varchar(25) not null,
    lieu    varchar(35) not null
);

create table praticien
(
    id           int auto_increment PRIMARY KEY,
    nom          varchar(25) not null,
    prenom       varchar(30) not null,
    rue          varchar(50) not null,
    codePostal   varchar(5)  not null,
    ville        varchar(30) not null,
    telephone    varchar(14) null unique,
    email        varchar(75) null unique,
    idType       varchar(3)  not null references typePraticien,
    idSpecialite varchar(5)  null references specialite
);

create table visiteur
(
    id           varchar(3) PRIMARY KEY,
    nom          varchar(25) not null,
    prenom       varchar(50) not null,
    rue          varchar(50) not null,
    codePostal   varchar(5)  not null,
    ville        varchar(45) not null,
    dateEmbauche Date        not null,
    dateDepart   date        null,
    idDepartement varchar(3) not null references departement
);

create table motif
(
    id      int auto_increment primary key,
    libelle varchar(60) not null
);

create table visite
(
    id                int auto_increment primary key,
    dateEtHeure       datetime    not null,
    bilan             text        null,
    idMotif           int         not null references motif,
    idVisiteur        varchar(3)  not null references visiteur,
    idPraticien       int         not null references praticien,
    premierMedicament varchar(10) null references medicament,
    secondMedicament  varchar(10) null references medicament
);

Create table echantillon
(
    idVisite     int         not null references visite,
    idMedicament varchar(10) not null references medicament,
    quantite     int         not null default 1,
    Primary Key (idVisite, idMedicament)
);


-- ------------------------------------------------------------------------------------------------
-- déclencheur concernant l'ajout d'un visiteur
-- ------------------------------------------------------------------------------------------------

-- il ne peut y avoir qu'un visiteur en activité (dateDepart is null) par département
-- si le département géré n'est pas précisé, il faut utiliser son département de résidence (deux premiers caractères du code postal)

create trigger avantAjoutVisiteur before insert on Visiteur
for each row
begin
    if new.idDepartement is null then
        set new.idDepartement = substring(new.codePostal, 1, 2);
    end if;
	if exists(select 1 from visiteur where idDepartement = new.idDepartement and dateDepart is null) then
		SIGNAL sqlstate '45000' set message_text = 'Un visiteur en activité gère déjà ce département';
	end if;
end;


-- Remarque à chaque visiteur doit correspondre un utilisateur dans la base de données.
-- Il n'est cependant pas possible de générer l'utilisateur à l'aide d'un trigger car une trigger comme une fonction stockée n'acccepte pas les requêtes SQL dynamiques (requête avec paramètre)



