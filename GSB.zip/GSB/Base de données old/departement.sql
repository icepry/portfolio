-- alimentation de la table département à partir du fichier departement.csv

-- indication
-- on dispose d'une source de données au format csv obtenue sur https://www.data.gouv.fr/fr/datasets/regions-departements-villes-et-villages-de-france-et-doutre-mer/
-- la structure de ce fichier ne correspond pas à notre table departement

-- pour récupérer les données il faut créer une table temporaire 'departements' de même structure que le fichier csv
-- on y transfère les données par la commande load data
-- puis on transfère les colonnes utiles de cette table dans la table département

use gsb;

-- création d'une table de transfert 'departements' en mémoire dont la structure est identique au fichier csv
-- Les tables en mémoire sont volatiles et les données seront perdues en cas de redémarrage du serveur MySQL.

CREATE TABLE departements (
    id INT,
    region_code INT,
    code VARCHAR(3),
    name VARCHAR(75),
    slug VARCHAR(75)
) ENGINE=MEMORY;

delete from departements;

-- chargement des données depuis le fichier csv departement.csv
-- attention à la première ligne qu'il ne faut pas prendre en compte et au jeu de caractères

-- solution 1 : placer le fichier departments.csv sur le serveur dans le répertoire tmp de wamp (c:/wamp64/tmp/departments.csv)
-- et utiliser la commande LOAD DATA INFILE

# connaitre le répertoire accessible sur le serveur
SHOW VARIABLES LIKE "secure_file_priv";

LOAD DATA INFILE 'C:/wamp64/tmp/departments.csv'
INTO TABLE departements
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;

select * from departements;
delete from departements;

# [HY000][1290] The MySQL server is running with the --secure-file-priv option so it cannot execute this statement

-- Solution 2 : utiliser la commande LOAD DATA LOCAL INFILE
-- Dans ce cas il faut que la variable global local_infile = 1

-- Connaitre la valeur de la variable globale
select @@local_infile;
-- Si la valeur retournée est 0, activez local_infile
SET GLOBAL local_infile = true;

LOAD DATA local INFILE 'departments.csv'
INTO TABLE departements
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;

-- [42000][3948] Loading local data is disabled; this must be enabled on both the client and server sides

-- solution coté serveur : modifier la propriété  'local_infile' :allowloadlocalinfile


select * from departements;

-- suppression des anciens enregistrements de la table departement


-- ajout des enregistrements de la table temporaire dans la table departement
-- sans prendre les départements des DOM-TOM (les code sur trois caractères)
-- en utilisant le champ slug pour remplir le champ nom

insert into departement (code, nom)
    select code, slug
    from departements
    WHERE LENGTH(code) = 2;


select * from departement order by code;



