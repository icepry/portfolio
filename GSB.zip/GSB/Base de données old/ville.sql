-- alimentation de la table ville


-- indication
-- on dispose d'une source de données au format sql obtenue sur https://www.data.gouv.fr/fr/datasets/regions-departements-villes-et-villages-de-france-et-doutre-mer/
-- ce fichier cities.sql génère une table cities
-- la structure de cette table ne correspond pas à notre table ville

use gsb;

-- vider la table ville
Delete from ville;

-- exécuter le script cities.sql afin de créer la table cities qui va servir à mettre à jour la table ville

Select * from cities;


-- alimenter la table ville avec les lignes de la table cities en limitant aux départements métropolitains (code département à 2 caractères)
insert into ville(idDepartement, idCommune, nom, codePostal)
   select department_code, insee_code, name, zip_code
    from cities
    where length(department_code) = 2;

select * from ville;

drop table cities;


-- select * from cities where insee_code = "01050";

-- un code postal peut correspondre à plusieurs villes
-- un code insee commune peut avoir plusieurs codes postaux ex : amiens

-- 46,01,01050,01190,Boissey,boissey,46.3812,4.996962
-- 47,01,01050,01380,Boissey,boissey,46.3812,4.996962

select * from ville where codePostal= '80600'

Select idcommune, count(*)
from ville
group by idcommune
having count(*) > 1;

select * from ville
where idCommune = '80021';


Select * from ville
where nom = 'Paris';