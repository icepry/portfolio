use gsb;

-- création d'un utilisateur MySQL pour chaque visiteur dont l'id correspond au nom de l'utilisateur (auquel on ajoute @localhost) et la date d'embauche au format aaaammjj représente le mot de passe
-- chaque utilisateur pourra accéder en lecture aux vues, aux tables dites 'non sensibles' (motif, specialite, typePraticien, famille, medicament)
-- chaque utilisateur pourra exécuter des procédures

-- rappel : il n'est pas possible de réaliser ce travail à l'aide d'un trigger car comme pour les fonctions stockées, les requêtes dynamiques ne sont pas acceptées

-- Donner un accès aux vues mesVisites ou mesPraticiens en modification n'est pas sécurisé, car il serait alors possible qu'un visiteur x ajouter une visite pour un visiteur y
-- sous reserve de lui attribuer un praticien du visiteur y

-- Pour créer un utilisateur à chaque visiteur, il faut écrire une procédure qui parcourt à l'aide d'un curseur la table visiteur


-- Tous les visiteurs ont un accès en lecture au même ensemble de tables et de vues.
-- Il est donc plus judicieux de créer un role visiteurs et de lui donner les droits

-- création du rôle visiteur

-- remarque : il semble que Mysql 9 ne permet plus de donner des droits sur des objets qui n'existent pas encore

DROP ROLE IF EXISTS visiteurs;
CREATE ROLE visiteurs;

-- Attribution des droits sur les tables
GRANT SELECT ON famille TO visiteurs;
GRANT SELECT ON medicament TO visiteurs;
GRANT SELECT ON motif TO visiteurs;
GRANT SELECT ON specialite TO visiteurs;
GRANT SELECT ON typepraticien TO visiteurs;
GRANT SELECT ON levisiteur TO visiteurs;
GRANT SELECT ON mesvilles TO visiteurs;
GRANT SELECT ON mesvisites TO visiteurs;
GRANT SELECT ON mespraticiens TO visiteurs;
GRANT SELECT ON mesechantillons TO visiteurs;

-- Attribution des droits d'exécution sur les procédures
GRANT EXECUTE ON PROCEDURE ajouterRendezVous TO visiteurs;
GRANT EXECUTE ON PROCEDURE modifierRendezVous TO visiteurs;
GRANT EXECUTE ON PROCEDURE supprimerRendezVous TO visiteurs;
GRANT EXECUTE ON PROCEDURE enregistrerBilanVisite TO visiteurs;
GRANT EXECUTE ON PROCEDURE ajouterPraticien TO visiteurs;
GRANT EXECUTE ON PROCEDURE modifierPraticien TO visiteurs;
GRANT EXECUTE ON PROCEDURE supprimerPraticien TO visiteurs;
GRANT EXECUTE ON PROCEDURE ajouterEchantillon TO visiteurs;

-- Suppression et recréation de la procédure
DROP PROCEDURE IF EXISTS createuser;

CREATE PROCEDURE createuser()
BEGIN
    DECLARE idVisiteur VARCHAR(3);
    DECLARE mdp VARCHAR(8);
    DECLARE finCurseur INT DEFAULT 0;
    DECLARE listeUser CURSOR FOR
        SELECT id, DATE_FORMAT(dateEmbauche, '%Y%m%d') FROM visiteur;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET finCurseur = 1;

    OPEN listeUser;
    FETCH listeUser INTO idVisiteur, mdp;
    WHILE finCurseur = 0
        DO
            -- Afin de pouvoir relancer la procédure, on supprime l'utilisateur s'il existe
            set @sql = concat('drop user if exists ', idVisiteur, '@localhost');
            prepare requete from @sql;
            execute requete;

            -- création de l'utilisateur
            set @sql = concat('create user ', idVisiteur, '@localhost identified by ''', mdp, '''');
            prepare requete from @sql;
            execute requete;

            -- Attribution du rôle visiteurs
            SET @sql = CONCAT('GRANT visiteurs TO ', idVisiteur, '@localhost');
            PREPARE requete FROM @sql;
            EXECUTE requete;

            -- Définir le rôle par défaut
            SET @sql = CONCAT('SET DEFAULT ROLE visiteurs To ', idVisiteur, '@localhost');
            PREPARE requete FROM @sql;
            EXECUTE requete;

            FETCH listeUser INTO idVisiteur, mdp;
        END WHILE;
    CLOSE listeUser;
END;

-- Exécution de la procédure
CALL createuser();

-- Appliquer les privilèges
FLUSH PRIVILEGES;


