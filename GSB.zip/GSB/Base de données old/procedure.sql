-- -------------------------------------------
-- Programme : procedures.sql
-- Objet : procédures stockées du projet GSB 
-- Serveur : MySQL 
-- Auteur :
-- Date : 
-- -------------------------------------------

use gsb;


-- ajouter un rendez-vous
drop procedure if exists ajouterRendezVous;
CREATE  PROCEDURE ajouterRendezVous (_idPraticien INT, _idMotif INT, _dateEtHeure DATETIME, OUT _idVisite INT)  sql security definer
begin
    -- contrôle sur le format attendu pour _idPraticien
     if not (_idPraticien REGEXP '^[0-9]+$') then
        signal sqlstate '45000'
        set message_text = 'L''identifiant du praticien n''est as valide';
    end if;

    -- Vérification du praticien
    if not exists(select * from mespraticiens where id = _idPraticien) then
        signal sqlstate '45000' set message_text = 'Ce praticien n''est pas dans le secteur du visiteur';
    end if;

    -- contrôle sur le format attendu pour _idMotif
    if not (_idMotif REGEXP '^[0-9]+$') then
        signal sqlstate '45000'
        set message_text = 'L''identifiant du motif n''est pas valide';
    end if;

    -- vérification du motif
    if not exists(select * from motif where id = _idMotif) then
        signal sqlstate '45000' set message_text = 'Ce motif n''existe pas';
    end if;

    -- vérification de la date : elle doit être supérieure ou égal à la date actuelle + 1 heure

    if _dateEtHeure < now() + interval 1 hour then
        signal sqlstate '45000' set message_text = 'La date doit être supérieure ou égale à la date actuelle + 1 heure';
    end if;

    -- ajout dans la table visite
    insert into visite (dateEtHeure, idMotif, idVisiteur, idPraticien)
       values (_dateEtHeure, _idMotif, (select id from levisiteur) , _idPraticien);

    -- alimentation du paramètre en sortie avec l'identifiant (auto-increment) de la nouvelle visite
    set _idVisite = (select LAST_INSERT_ID());
end;



-- enregistrer le bilan d'une visite
drop procedure if exists enregistrerBilanVisite;

CREATE  PROCEDURE enregistrerBilanVisite (_idVisite INT, _bilan TEXT, _premierMedicament VARCHAR(10), _secondMedicament VARCHAR(10))  sql security definer
begin
    -- vérification de l'identifiant de la visite qui doit faire partie des visites du visiteur connecté


 -- le paramètre _bilan qui doit être renseigné


    -- vérification du premier médicament

    -- le paramètre _premierMedicament doit être renseigné et correspondre à un médicament

    -- vérification du second médicament s'il est renseigné (chaîne non vide)
    -- if char_length(secondMedicament) > 0 then
        -- vérification du second médicament

        -- modification bilan, premierMedicament et secondMedicament

	-- else
	    -- modification bilan et premierMedicament


	-- end if;
end;

-- modifier la planification d'une visite
drop procedure if exists modifierRendezVous;

CREATE  PROCEDURE modifierRendezVous (idVisite INT, dateEtHeure DATETIME)  sql security definer
begin
      -- vérification de l'identifiant de la visite qui doit faire partie des visites du visiteur connecté



    -- modification de la date dans la table visite



end;

-- supprimer une visite
drop procedure if exists supprimerRendezVous;

create procedure supprimerRendezVous(idVisite INT)  sql security definer
begin
     -- vérification de l'identifiant de la visite qui doit faire partie des visites du visiteur connecté

     -- suppression

end;

-- Ajoute un échantillon lors d'une visite
drop procedure if exists ajouterEchantillon;
CREATE PROCEDURE ajouterEchantillon (idVisite INT, idMedicament VARCHAR(10), quantite INT) sql security definer
begin
    -- vérification de l'identifiant de la visite qui doit faire partie des visites du visiteur connecté


    -- vérification du premier médicament


    -- ajout


end;



-- ajouter un praticien
-- le visiteur n'a pas le droit d'ajout dans la table Praticien car il pouurait ajouter un praticien hors département
-- la procédure sera donc lancée avec les droits du créateur (root) mais en vérifiant que le département est bien celui du visiteur
-- un champ optionnel ne pose pas de problème ici car le paramètre correspondant ici idSpecialite contient  Null
drop procedure if exists ajouterPraticien;

CREATE  PROCEDURE ajouterPraticien (nom VARCHAR(25), prenom VARCHAR(30), rue VARCHAR(50), codePostal VARCHAR(5), ville VARCHAR(25), telephone VARCHAR(14), email VARCHAR(75), idType VARCHAR(3), idSpecialite VARCHAR(5), OUT idPraticien INT) sql security definer
begin
    -- contrôle du département


    -- ajout

    -- récupération de l'identifiant

end;

-- modifier un praticien
-- un champ optionnel ne pose pas de problème ici car le paramètre correspondant ici idSpecialite contient  Null
drop procedure if exists modifierPraticien;

CREATE PROCEDURE modifierPraticien (_id int, _nom VARCHAR(25), _rue VARCHAR(50), _codePostal VARCHAR(5), _ville VARCHAR(25), _telephone VARCHAR(14), _email VARCHAR(75), _idType VARCHAR(3), _idSpecialite VARCHAR(5)) sql security definer
begin
    -- contrôle du département

    -- modification


end;

-- supprimer une praticien
drop procedure if exists supprimerPraticien;

create procedure supprimerPraticien(idPraticien INT) sql security definer
begin
    -- contrôle du département

    -- suppression

end;