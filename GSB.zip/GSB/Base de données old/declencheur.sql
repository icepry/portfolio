use gsb;


drop trigger if exists avantAjoutVisite;
drop trigger if exists avantAjoutEchantillon;
drop trigger if exists avantMajVisite;
drop trigger if exists avantMajEchantillon;

-- ------------------------------------------------------------------------------------------------
-- concernant l'ajout d'une visite
-- ------------------------------------------------------------------------------------------------

-- une visite peut se trouver dans trois états : 
--    programmée (seule la date , le praticien et le visiteur sont renseignés et la date n'est pas dépasée) 
--    réalisée  : la date est maintenant dépassée elle peut être cloturée en renseignant le bilan, les médicaments et les échantillons
--    cloturée  : plus rien n'est modifiable

-- lors de la programmation d'une viste (création) d'une visite il faut vérifier les contraintes suivantes :
-- un visiteur ne peut visiter que les praticiens qui résident dans le même département
-- le bilan et les médicaments qui seront présentés ne peuvent pas être renseignés lors de la création de la visite
-- il ne peut y avoir qu'une visite programmée par praticien (hors visite clôturée : avec bilan enregistré)
-- une visite doit être programmée au moins une heure à l'avance 
-- une visite ne peut être programmée plus de deux mois à l'avance
-- une visite ne peut se faire le dimanche
-- la plage horaire de prise de rendez-vous est fixée entre 8 heures et 19 heures compris
-- il doit y avoir au moins deux heures d'écart entre deux visites


-- pour construire le jeu d'essai, il faut permettre  à root de créer des visites dont la date est dépassée
 
create trigger avantAjoutVisite before insert on Visite
for each row
begin
    # dateEtHeure comprise entre aujourd'hui + 1 heure et aujourd'hui + 2 mois
    if new.dateEtHeure < now() + interval 1 hour then
        SIGNAL sqlstate '45000' set message_text = 'La visite doit être programmée au moins une heure à l''avance';
    end if;

    if new.dateEtHeure > now() + interval 2 month then
        SIGNAL sqlstate '45000' set message_text = 'La visite ne peut être programmée plus de deux mois à l''avance';
    end if;

    # pas le dimanche
    if dayofweek(new.dateEtHeure) = 1 then
        SIGNAL sqlstate '45000' set message_text = 'La visite ne peut se faire le dimanche';
    end if;

    # entre 8 et 19 heures
    if hour(new.dateEtHeure) not between 8 and 18 then
        SIGNAL sqlstate '45000' set message_text = 'La visite doit se faire entre 8 et 19 heures';
    end if;


    # pas de médicaments présentés ni de bilan à la création
    if new.premierMedicament is not null or new.secondMedicament is not null or new.bilan is not null then
        SIGNAL sqlstate '45000' set message_text = 'Le bilan et les médicaments ne peuvent pas être renseignés lors de la création de la visite';
    end if;

    # au moins deux heures entre chaque visite
    if exists(select 1 from visite where idPraticien = new.idPraticien
        and dateEtHeure between new.dateEtHeure - interval 2 hour and new.dateEtHeure + interval 2 hour) then
        SIGNAL sqlstate '45000' set message_text = 'Il ne peut y avoir qu''une visite programmée par praticien';
    end if;


    # une seule visite programmée par praticien
    if exists(select 1 from visite where idPraticien = new.idPraticien and bilan is null) then
        SIGNAL sqlstate '45000' set message_text = 'Il ne peut y avoir qu''une visite programmée par praticien';
    end if;


end;

-- ------------------------------------------------------------------------------------------------
-- concernant la modification d'une visite
-- ------------------------------------------------------------------------------------------------

-- première règle
--   trois champs ne sont pas modifiables : id, idPraticien et idVisiteur

-- seconde règle
--    Si la visite est close (bilan déjà renseigné) plus aucun champ ne doit être modifiable  

-- troisième règle : si on arrive ici on sait que la visite n'est pas close dont le bilan non renseigné
--                  Pourquoi ? si c'était le cas la règle deux ne serait pas respectée
-- si la date est modifiée elle doit respecter les 4 règles vues en création :
--    entre 8 et 19 heures hors dimanche, 
--    au plus tard dans les deux mois 
--    séparée d'au moins deux heures de la suivante ou de la précédente
--    au plus tôt dans une heure 

-- 4ème règle

-- si la visite n'est pas encore réalisée  (DateEtHeure > Now) 
--     les champs bilan, premierMedicament et SecondMedicament ne sont pas modifiables (ils doivent rester non renseignés)

-- 
-- sinon (la visite peut être clôurée)
--     Le bilan doit être renseigné si la colonne premierMedicament ou la colonne secondMedicament est renseigné
-- 	   si le bilan est renseigné le premier médicament doit être renseigné et sa valeur doit être différente du second médicament



create trigger avantMajVisite before update on Visite
for each row
begin
	-- Les champs non modifiables



    -- Si la visite est close (bilan déjà renseigné) plus aucun champ ne doit être modifiable 


    -- si la date est modifiée elle doit respecter les 4 règles : entre 8 et 19 heures hors dimanche, dans les deux mois et séparée d'au moins deux heures de la suivante ou de la précédente


    
    
    -- si la visite n'est pas encore réalisée  (DateEtHeure > Now) 

end;



-- ------------------------------------------------------------------------------------------------
-- concernant l'ajout des échantillons
-- ------------------------------------------------------------------------------------------------

-- L'ajout d'échantillon n'est possible que pour une visite dont le bilan est renseigné
-- dans ce cas le nombre de médicaments distribués ne doit pas dépasser 10
-- on récupère les champs bilan de la visite en les stockant dans des variables
-- si le bilan est null : erreur
-- si déjà 10 échantillons : erreur
-- la quantité doit être supérieure à 0 si elle est renseignée

create trigger avantAjoutEchantillon before insert on Echantillon
for each row
begin

end;

-- ------------------------------------------------------------------------------------------------
-- concernant la modification des échantillons
-- ------------------------------------------------------------------------------------------------

-- les colonnes idVisite et idMedicament ne sont pas modifiables
-- la quantité finale doit resté positive
create trigger avantMajEchantillon before update on Echantillon
for each row
begin


end;








