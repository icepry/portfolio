-- Test des opérations réalisable par le visiteur a18

-- utilisateur a18@localhost
-- password : 19850920

select user(), current_user(), session_user();

select * from leVisiteur;

select * from mesVisites;

select * from mesPraticiens;

select * from mesVilles;

SET ROLE visiteurs;
call ajouterRendezVous (101, 2, '2024-11-30',  @idVisite);
-- [45000][1644] Ce praticien n'est pas dans le secteur du visiteur