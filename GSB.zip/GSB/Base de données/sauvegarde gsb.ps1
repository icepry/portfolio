# Chemin vers mysqldump.exe
$mysqldumpPath = "C:\wamp64\bin\mysql\mysql9.1.0\bin\mysqldump.exe"

# V�rifier si mysqldump.exe existe
if (Test-Path $mysqldumpPath) {
    # Param�tres de la commande
    $user = "root"
    $database = "gsb"
    $outputFile = "gsb.sql"

    # Construire la commande
    $command = "& '$mysqldumpPath' -u $user $database --databases --add-drop-database --routines=true > $outputFile"

	# Pause
	Write-Host "Lancement de l'exportation de la base de donn�es GSB"

    # Ex�cuter la commande
    try {
        Invoke-Expression $command
        Write-Host "L'exportation de la base de donn�es GSB a �t� r�alis�e avec succ�s. Le fichier de sortie est : $outputFile"
    }
    catch {
        Write-Host "Une erreur s'est produite lors de l'exportation : $_"
    }
}
else {
    Write-Host "Le fichier mysqldump.exe n'a pas �t� trouv� � l'emplacement sp�cifi� : $mysqldumpPath"
}
