use gsb;

-- création d'un utilisateur MySQL pour chaque visiteur dont l'id correspond au nom de l'utilisateur (auquel on ajoute @localhost) et la date d'embauche au format aaaammjj représente le mot de passe
-- chaque utilisateur pourra accéder en lecture aux vues, aux tables dites 'non sensibles' (motif, specialite, typePraticien, famille, medicament)
-- chaque utilisateur pourra exécuter des procédures

-- rappel : il n'est pas possible de réaliser ce travail à l'aide d'un trigger car comme pour les fonctions stockées, les requêtes dynamiques ne sont pas acceptées

-- Donner un accès aux vues mesVisites ou mesPraticiens en modification n'est pas sécurisé, car il serait alors possible qu'un visiteur x ajouter une visite pour un visiteur y
-- sous reserve de lui attribuer un praticien du visiteur y

-- Pour créer un utilisateur à chaque visiteur, il faut écrire une procédure qui parcourt à l'aide d'un curseur la table visiteur


-- Tous les visiteurs ont un accès en lecture au même ensemble de tables et de vues.
-- Il est donc plus judicieux de créer un role visiteurs et de lui donner les droits

-- création du rôle visiteur

-- remarque : Mysql 9 ne permet plus de donner des droits sur des objets qui n'existent pas encore

drop role if exists visiteurs;
create role visiteurs;
grant select on famille to visiteurs;
grant select on medicament to visiteurs;
grant select on motif to visiteurs;
grant select on specialite to visiteurs;
grant select on typepraticien to visiteurs;
grant select on levisiteur to visiteurs;
grant select on mesvilles to visiteurs;
grant select on mesvisites to visiteurs;
grant select on mespraticiens to visiteurs;
grant select on mesechantillons to visiteurs;

-- au niveau des procédures stockées on attribut le droit de les éxécuter toutes afin d'en faciliter l'ajout éventuelle
grant execute on procedure  ajouterRendezVous to visiteurs;
grant execute on procedure  modifierRendezVous to visiteurs;
grant execute on procedure  supprimerRendezVous to visiteurs;
grant execute on procedure  enregistrerBilanVisite to visiteurs;
grant execute on procedure  ajouterPraticien to visiteurs;
grant execute on procedure  modifierPraticien to visiteurs;
grant execute on procedure  supprimerPraticien to visiteurs;
grant execute on procedure  ajouterEchantillon to visiteurs;

-- attribution des droits sur ce rôle


-- La procédure est alors chargée de créer les utilisateurs et de les "placer dans le groupe"
-- dans la philosophie Mysql on donne le rôle aux utilisateurs

drop procedure if exists createuser;

create procedure createuser()
  begin
		declare idVisiteur varchar(3);
		declare mdp varchar(8);
		declare finCurseur int default 0;
		declare listeUser cursor for
	    	select id, Date_Format(dateEmbauche, '%Y%m%d') from visiteur;
		declare continue handler for sqlstate '02000' set finCurseur = 1;

		open listeUser;
		fetch listeUser into idVisiteur, mdp;
		while finCurseur = 0 Do
		    -- Afin de pouvoir relancer la procédure on supprimer l'utilisateur s'il existe
            set @sql = concat('drop user if exists ', idVisiteur, '@localhost');
            prepare requete from @sql;
            execute requete;

		    -- création de l'utilisateur
            set @sql = concat('create user ', idVisiteur, '@localhost identified by ''', mdp, ''' default role visiteurs');
            prepare requete from @sql;
            execute requete;

		    -- attribution du role visiteur
            set @sql = concat('grant visiteurs to ', idVisiteur, '@localhost');
            prepare requete from @sql;
            execute requete;
-- attribution des droits pour pouvoir exécuter des procédures : probème C#
            set @sql = concat('GRANT EXECUTE ON gsb.* TO ',  idVisiteur, '@localhost');
            prepare requete from @sql;
            execute requete;
			fetch listeUser into idVisiteur, mdp;
		end while;
		close listeUser;
  end;

call createuser();


