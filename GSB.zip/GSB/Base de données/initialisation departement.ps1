# D�finir l'encodage de la console
$OutputEncoding = [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding

# utilisation de l'assembly MySql.Data.dll
# chemin de la dll "C:\Program Files (x86)\MySQL\MySQL Connector NET 9.1\MySql.Data.dll" 

try {
    Add-Type -Path "MySql.Data.dll"
} catch {
    # Ignorer l'erreur, ne rien faire
}
# URL de l'API Geo pour r�cup�rer les d�partements
$url = "https://geo.api.gouv.fr/departements"

# Configuration de la base MySQL
$server = "localhost" 
$database = "gsb"     
$username = "root"     
$password = "" 

# Connexion � la base MySQL
$connectionString = "server=$server;database=$database;uid=$username;pwd=$password"
$cnx = New-Object MySql.Data.MySqlClient.MySqlConnection
$cnx.ConnectionString = $connectionString

try {
    Write-Host "Connexion � la base de donn�es MySQL..."
    $cnx.Open()
    Write-Host "Connexion r�ussie."

    # Requ�te HTTP pour r�cup�rer les donn�es
	Write-Host "R�cup�ration des donn�es depuis l'API $url"
	$response = Invoke-RestMethod -Uri $url -Method Get

    if ($response) {
		Write-Host "Parcours de la r�ponse au format json pour g�n�rer les departements"
		$cmd = $cnx.CreateCommand()
        foreach ($departement in $response) {
            # Exclure les d�partements dont le code est compos� de 3 caract�res (DOM)
            if ($departement.code.Length -eq 3) {
                continue
            }
            # �chapper les apostrophes dans le nom du d�partement
            $escapedName = $departement.nom -replace "'", "\'"
            $sql = @"
INSERT INTO departement (code, nom)
VALUES ('$($departement.code)', '$escapedName');
"@
			$cmd.CommandText = $sql
            $cmd.ExecuteNonQuery()| Out-Null
        }
        Write-Host "Insertion termin�e."
    } else {
        Write-Host "Erreur lors de l'acc�s � l'API."
    }

} catch {
    Write-Host "Une erreur s'est produite : $_"
} finally {
    # Fermeture de la connexion MySQL
    if ($cnx.State -eq [System.Data.ConnectionState]::Open) {
        $cnx.Close()
        Write-Host "Connexion � la base MySQL ferm�e."
    }
}


