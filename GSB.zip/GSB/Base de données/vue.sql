-- création des vues dynamiques permettant de récupérer uniquement les informations concernant l'utilisateur connecté à la base de données
use gsb;

-- récupérer le nom - prénom du visiteur connecté

drop view if exists leVisiteur;

create view leVisiteur(id, nomPrenom, idDepartement) as
    select id, concat(nom, ' ', prenom), idDepartement
	from visiteur
     where concat(visiteur.id, '@localhost') = user();

-- récupérer les praticiens gérés par le visiteur connecté
-- une praticien qui réside dans le département x (2 premiers caractères de son code postal) est géré par le visiteur affecté au département x (idDepartement)
drop view if exists mesPraticiens;

create view mesPraticiens as
    Select id, nom, prenom, rue, codePostal, ville, telephone, email, idType, idSpecialite
    from praticien
    where substring(codePostal, 1, 2) = (select idDepartement from leVisiteur);



-- récupérer les villes (nom et code postal) situées dans le département géré par le visiteur connecté

drop view if exists mesVilles;

create view mesVilles (nom, codePostal)  as
    select nom, codePostal
    from ville
    where idDepartement = (select idDepartement from leVisiteur)
    order by nom;

-- récupérer les visites du visiteur connecté

drop view if exists mesVisites;

create view mesVisites as
    select id, dateEtHeure, bilan, idMotif, idPraticien, premierMedicament, secondMedicament
    from visite
    where idVisiteur = (select id from leVisiteur)
    order by dateEtHeure;


-- récupérer les échantillons fournis lors des visites pour le visiteur connecté

drop view if exists mesEchantillons;

create view mesEchantillons as
    select idVisite, idMedicament, quantite
    from echantillon
    where idVisite in (select id from mesVisites)
    order by idVisite, idMedicament;

