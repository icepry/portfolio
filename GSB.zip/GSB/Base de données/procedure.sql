-- -------------------------------------------
-- Programme : procedures.sql
-- Objet : procédures stockées du projet GSB 
-- Serveur : MySQL 
-- Auteur :
-- Date : 
-- -------------------------------------------

use gsb;


-- ajouter un rendez-vous
drop procedure if exists ajouterRendezVous;
CREATE  PROCEDURE ajouterRendezVous (_idPraticien INT, _idMotif INT, _dateEtHeure DATETIME, OUT _idVisite INT)  sql security definer
begin
    -- Vérification du praticien
    if not exists(select 1 from mespraticiens where id = _idPraticien) then
       SIGNAL sqlstate '45000' set message_text = 'Ce praticien n''est pas dans le secteur du visiteur.';
    end if;

    -- vérification du motif
    if not exists(select 1 from motif where id = _idMotif) then
            SIGNAL sqlstate '45000' set message_text = 'Ce motif n''existe pas.';
    end if;

    -- dateEtHeure > à aujourd'hui + 1 heure
    if _dateEtHeure < date_add(now(), interval 1 hour) then
        SIGNAL sqlstate '45000' set message_text = 'Il n''est pas possible de programmer un rendez-vous dans moins d''une heure.';
    end if;

    -- dateEtHeure < à aujourd'hui + 2 mois
    if _dateEtHeure > date_add(now(), interval 2 month) then
        SIGNAL sqlstate '45000' set message_text = 'Une visite ne peut être programmée plus de 2 mois à l''avance.';
    end if;

    -- pas le dimanche
    IF DAYOFWEEK(_dateEtHeure) = 1 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Une visite ne peut pas se dérouler un dimanche.';
    END IF;

    -- entre 8 et 19 heures
    IF HOUR(_dateEtHeure) < 8 OR HOUR(_dateEtHeure) >= 19 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Une visite doit se situer entre 8 et 19 heures.';
    END IF;

    -- au moins deux heures entre chaque visite
    IF EXISTS (
        SELECT 1
        FROM visite
        WHERE idVisiteur = (SELECT id FROM levisiteur)
          AND dateEtHeure BETWEEN _dateEtHeure - INTERVAL 2 HOUR + INTERVAL 1 MINUTE
            AND _dateEtHeure + INTERVAL 2 HOUR - INTERVAL 1 MINUTE
    ) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Il faut au moins deux heures d''écart entre deux visites.';
    END IF;

    -- une seule visite programmée par praticien
    IF EXISTS (
        SELECT 1
        FROM visite
        WHERE idVisiteur = (SELECT id FROM levisiteur)
          AND idPraticien = _idPraticien
          AND bilan IS NULL
    ) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Une visite non clôturée existe déjà pour ce praticien';
    END IF;


    -- ajout dans la table visite : l'id du visiteur est récupérée à partir de la vue leVisiteur
	insert into visite (idVisiteur, idPraticien, idMotif, dateEtHeure) values
			((select id from levisiteur), _idPraticien, _idMotif, _dateEtHeure);

    -- alimentation du paramètre en sortie avec l'identifiant (auto-increment) de la nouvelle visite
	set _idVisite = (select @@IDENTITY);
end;



-- enregistrer le bilan d'une visite
drop procedure if exists enregistrerBilanVisite;

CREATE  PROCEDURE enregistrerBilanVisite (_idVisite INT, _bilan TEXT, _premierMedicament VARCHAR(10), _secondMedicament VARCHAR(10))  sql security definer
begin
    -- vérification de l'identifiant de la visite qui doit faire partie des visites du visiteur connecté


 -- le paramètre _bilan qui doit être renseigné


    -- vérification du premier médicament

    -- le paramètre _premierMedicament doit être renseigné et correspondre à un médicament

    -- vérification du second médicament s'il est renseigné (chaîne non vide)
    -- if char_length(secondMedicament) > 0 then
        -- vérification du second médicament

        -- modification bilan, premierMedicament et secondMedicament

	-- else
	    -- modification bilan et premierMedicament


	-- end if;
end;

-- modifier la planification d'une visite
drop procedure if exists modifierRendezVous;

CREATE  PROCEDURE modifierRendezVous (idVisite INT, dateEtHeure DATETIME)  sql security definer
begin
      -- vérification de l'identifiant de la visite qui doit faire partie des visites du visiteur connecté



    -- modification de la date dans la table visite



end;

-- supprimer une visite
drop procedure if exists supprimerRendezVous;

create procedure supprimerRendezVous(idVisite INT)  sql security definer
begin
     -- vérification de l'identifiant de la visite qui doit faire partie des visites du visiteur connecté

     -- suppression

end;

-- Ajoute un échantillon lors d'une visite
drop procedure if exists ajouterEchantillon;
CREATE PROCEDURE ajouterEchantillon (idVisite INT, idMedicament VARCHAR(10), quantite INT) sql security definer
begin
    -- vérification de l'identifiant de la visite qui doit faire partie des visites du visiteur connecté


    -- vérification du premier médicament


    -- ajout


end;



-- ajouter un praticien
-- le visiteur n'a pas le droit d'ajout dans la table Praticien car il pouurait ajouter un praticien hors département
-- la procédure sera donc lancée avec les droits du créateur (root) mais en vérifiant que le département est bien celui du visiteur
-- un champ optionnel ne pose pas de problème ici car le paramètre correspondant ici idSpecialite contient  Null
drop procedure if exists ajouterPraticien;

CREATE  PROCEDURE ajouterPraticien (nom VARCHAR(25), prenom VARCHAR(30), rue VARCHAR(50), codePostal VARCHAR(5), ville VARCHAR(25), telephone VARCHAR(14), email VARCHAR(75), idType VARCHAR(3), idSpecialite VARCHAR(5), OUT idPraticien INT) sql security definer
begin
    -- contrôle du département


    -- ajout

    -- récupération de l'identifiant

end;

-- modifier un praticien
-- un champ optionnel ne pose pas de problème ici car le paramètre correspondant ici idSpecialite contient  Null
drop procedure if exists modifierPraticien;

CREATE PROCEDURE modifierPraticien (_id int, _nom VARCHAR(25), _rue VARCHAR(50), _codePostal VARCHAR(5), _ville VARCHAR(25), _telephone VARCHAR(14), _email VARCHAR(75), _idType VARCHAR(3), _idSpecialite VARCHAR(5)) sql security definer
begin
    -- contrôle du département

    -- modification


end;

-- supprimer une praticien
drop procedure if exists supprimerPraticien;

create procedure supprimerPraticien(idPraticien INT) sql security definer
begin
    -- contrôle du département

    -- suppression

end;