# utilisation de l'assembly MySql.Data.dll
# chemin de la dll "C:\Program Files (x86)\MySQL\MySQL Connector NET 9.1\MySql.Data.dll" 

try {
    Add-Type -Path "MySql.Data.dll"
} catch {
    # Ignorer l'erreur, ne rien faire
}

# URL de l'API Geo pour r�cup�rer les villes fran�aise
$url = "https://geo.api.gouv.fr/communes?fields=nom,code,codesPostaux,codeDepartement&format=json"

# Configuration de la base MySQL
$server = "localhost" 
$database = "gsb"     
$username = "root"     
$password = "" 

# Connexion � la base MySQL
$connectionString = "server=$server;database=$database;uid=$username;pwd=$password"
$cnx = New-Object MySql.Data.MySqlClient.MySqlConnection
$cnx.ConnectionString = $connectionString

try {
    Write-Host "Connexion � la base de donn�es MySQL..."
    $cnx.Open()

    # Requ�te HTTP pour r�cup�rer les donn�es
    Write-Host "R�cup�ration des donn�es depuis l'API $url"
    $response = Invoke-RestMethod -Uri $url -Method Get

    if ($response) {
        Write-Host "Suppression des enregistrements existants dans la table ville."
        $sql = "DELETE FROM ville;"
        $cmd = $cnx.CreateCommand()
        $cmd.CommandText = $sql
        $cmd.ExecuteNonQuery()| Out-Null

		Write-Host "Parcours de la r�ponse au format json pour g�n�rer les villes"
		Write-Host "Veuillez patienter, ce traitement prend environ une minute..."
        foreach ($commune in $response) {
            # Exclure les d�partements dont le code est compos� de 3 caract�res (DOM)
            if ($commune.codeDepartement.Length -eq 3) {
                continue
            }
            foreach ($codePostal in $commune.codesPostaux) {
                 # �chapper les apostrophes dans le nom de la commune
                 $escapedName = $commune.nom -replace "'", "\'"
                 $sql = @"
INSERT INTO ville (idDepartement, idCommune, nom, codePostal)
VALUES ('$($commune.codeDepartement)', '$($commune.code)', '$escapedName', '$codePostal');
"@
				 $cmd.CommandText = $sql
                 $cmd.ExecuteNonQuery()| Out-Null
            }
        }
        Write-Host "Insertion termin�e."
    } else {
        Write-Host "Erreur lors de l'acc�s � l'API."
    }

} catch {
    Write-Host "Une erreur s'est produite : $_"
} finally {
    # Fermeture de la connexion MySQL
    if ($cnx.State -eq [System.Data.ConnectionState]::Open) {
        $cnx.Close()
    }
}

Pause

