-- Test des opérations réalisables par le visiteur a18

-- utilisateur a18@localhost
-- password : 19850920

select user(), current_user(), session_user();

select * from leVisiteur;

select * from mesVisites;

select * from mesPraticiens;

select * from mesVilles;



