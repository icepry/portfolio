-- Test des opérations réalisables par le visiteur a17
-- script à lancer sous le compte a17

-- utilisateur a17@localhost
-- password : 19910826

select user(), current_user(), session_user();

-- on vérifie que l'utilisateur a bien le rôle visiteurs
show grants for a17@localhost;

-- si le rôle visiteur n'est pas activé par défaut il faudrait lancer la commande  set role visiteurs;

-- on vérifie que l'utilisateur a bien le rôle visiteurs

select * from leVisiteur;

select * from gsb.mesVisites;

select * from mesPraticiens;

select * from mesVilles;

select * from medicament;

select * from mesEchantillons;

-- test sur l'absence de droit sur les tables visite, visiteur, praticien, echantillon

Select * from visite;
-- [42000][1142] La commande 'SELECT' est interdite à l'utilisateur: 'a17'@'@localhost' sur la table 'visite'
Select * from visiteur;
-- [42000][1142] La commande 'SELECT' est interdite à l'utilisateur: 'a17'@'@localhost' sur la table 'visiteur'
Select * from praticien;
-- [42000][1142] La commande 'SELECT' est interdite à l'utilisateur: 'a17'@'@localhost' sur la table 'praticien'
Select * from echantillon;
-- [42000][1142] La commande 'SELECT' est interdite à l'utilisateur: 'a17'@'@localhost' sur la table 'echantillon'


-- test de l'ajout d'une visite
set @lundi = current_date() - interval weekday(current_date) day + interval 21 day ;
select @lundi + interval 10 hour;
call ajouterRendezVous (101, 2, @lundi + interval 10 hour,  @idVisite);
select @idVisite;
-- réponse : [45000][1644] Une visite non clôturée existe déjà pour ce praticien

set @lundi = current_date() - interval weekday(current_date) day + interval 21 day ;
call ajouterRendezVous (110, 2, @lundi + interval 10 hour,  @idVisite);
select @idVisite;

-- réponse acceptée : 22

-- À réaliser après avoir complété les procédures enregistrerBilanVisite et ajouterEchantillon

-- test procédure enregistrerBilanVisite sur la visite 3

call enregistrerBilanVisite (3, '', 'ADIMOL9', '');

-- [45000][1644] Vous n'avez pas transmis le bilan

call enregistrerBilanVisite (3, 'Très satisfaisant', '', '');

-- [45000][1644] Vous n'avez pas indiqué le premier médicament présenté

call enregistrerBilanVisite (3, 'Très satisfaisant', 'xxx', '');

-- [45000][1644] Le premier médicament présenté n'existe pas


call enregistrerBilanVisite (3, 'Très satisfaisant', 'ADIMOL9', 'xxx');

-- [45000][1644] Le second médicament présenté n'existe pas

call enregistrerBilanVisite (3, 'Très satisfaisant', 'ADIMOL9', '');

-- accepté

call enregistrerBilanVisite (3, 'Très satisfaisant', 'ADIMOL9', '');

-- [45000][1644] Aucune modification n'est possible sur une visite clôturée

select * from mesVisites where id = 3;


-- test procédure ajouterEchantillon

call ajouterEchantillon (4, 'AMOPIL7', 2);

-- [45000][1644] Le bilan de la visite doit être renseigné pour pouvoir ajouter des échantillons

call ajouterEchantillon (5, 'AMOPIL7', 2);

-- [45000][1644] Cette visite ne vous concerne pas

call ajouterEchantillon (3, '', 0);

-- [45000][1644] Vous n'avez pas renseigné le médicament fourni en échantillon

call ajouterEchantillon (3, 'AMOPIL7', 0);

-- [45000][1644] La quantité doit être positive

call ajouterEchantillon (3, 'AMOPIL7', 2);
call ajouterEchantillon (3, 'AMOXIG12', 2);
call ajouterEchantillon (3, 'APATOUX22', 2);
call ajouterEchantillon (3, 'AMOXIG12', 2);
-- accepté la quantité passe à 4
call ajouterEchantillon (3, 'BACTIG10', 2);
call ajouterEchantillon (3, 'CARTION6', 2);
call ajouterEchantillon (3, 'AMOXIG12', 2);

-- accepté la quantité passe à 6

call ajouterEchantillon (3, 'BITALV', 2);
call ajouterEchantillon (3, 'CLAZER6', 2);
call ajouterEchantillon (3, 'DEPRIL9', 2);
call ajouterEchantillon (3, 'DIMIRTAM6', 2);
call ajouterEchantillon (3, 'EVILR7', 2);

select * from mesEchantillons where idVisite = 3;

call ajouterEchantillon (3, 'JOVAI8', 2);

-- [45000][1644] Il n'est pas possible de distribuer plus de 10 médicaments en échantillon


-- lesPraticiens

call ajouterPraticien ('Dupont', 'Henry', '4 grande avevue', '80000', 'amiens', '0664251478', 'dupont@free.fr', 'MH', '', @idPraticien);
select @idPraticien;
select * from mesPraticiens;
call supprimerPraticien(@idPraticien);
select * from mesPraticiens;


call supprimerPraticien(122);

-- [45000][1644] Le praticien n'est pas dans le secteur du visiteur

call supprimerPraticien(1);
-- [45000][1644] Ce praticien ne peut pas être supprimé

-- Ajout dans la vue mesVisites interdit

set @lundi = current_date() - interval weekday(current_date) day + interval 14 day ;
select @lundi;
insert into mesvisites (dateEtHeure, idMotif, idVisiteur, idPraticien) values
  (@lundi + interval 15 hour, 1, 'a17', 112);

-- si on donne le droit insert sur la vue mesvisites il est malheureusement possible d'ajouter une visite pour un autre visiteur

set @mardi = current_date() - interval weekday(current_date) day + interval 15 day ;
select @mardi;
insert into mesvisites (dateEtHeure, idMotif, idVisiteur, idPraticien) values
  (@mardi + interval 15 hour, 1, 'a18', 124);

