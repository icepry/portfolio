use gsb;


drop trigger if exists avantAjoutVisite;
drop trigger if exists avantAjoutEchantillon;
drop trigger if exists avantMajVisite;
drop trigger if exists avantMajEchantillon;

-- ------------------------------------------------------------------------------------------------
-- concernant l'ajout d'une visite
-- ------------------------------------------------------------------------------------------------

-- une visite peut se trouver dans trois états : 
--    programmée (seule la date , le praticien et le visiteur sont renseignés et la date n'est pas dépasée) 
--    réalisée  : la date est maintenant dépassée elle peut être cloturée en renseignant le bilan, les médicaments et les échantillons
--    cloturée  : plus rien n'est modifiable

-- lors de la programmation d'une viste (création) d'une visite il faut vérifier les contraintes suivantes :
-- un visiteur ne peut visiter que les praticiens qui résident dans le même département
-- le bilan et les médicaments qui seront présentés ne peuvent pas être renseignés lors de la création de la visite
-- il ne peut y avoir qu'une visite programmée par praticien (hors visite clôturée : avec bilan enregistré)
-- une visite doit être programmée au moins une heure à l'avance 
-- une visite ne peut être programmée plus de deux mois à l'avance
-- une visite ne peut se faire le dimanche
-- la plage horaire de prise de rendez-vous est fixée entre 8 heures et 19 heures compris
-- il doit y avoir au moins deux heures d'écart entre deux visites


-- pour construire le jeu d'essai, il faut permettre à root de créer des visites dont la date est dépassée
 
create trigger avantAjoutVisite before insert on Visite
for each row
begin
    # Vérification du praticien
    if not exists(select 1 from praticien where id = new.idPraticien) then
        SIGNAL sqlstate '45000' set message_text = 'Ce praticien n''est pas dans le secteur du visiteur';
    end if;

    # vérification du motif
    if not exists(select 1 from motif where id = new.idMotif) then
        SIGNAL sqlstate '45000' set message_text = 'Ce motif n''existe pas';
    end if;

    # dateEtHeure > à aujourd'hui + 1 heure
    if new.dateEtHeure < now() + interval 1 hour and user() != 'root@localhost' then
        SIGNAL sqlstate '45000' set message_text = 'Il n''est pas possible de programmer un rendez-vous dans moins d''une heure';
    end if;

    # dateEtHeure < à aujourd'hui + 2 mois
    if new.dateEtHeure > now() + interval 2 month then
        SIGNAL sqlstate '45000' set message_text = 'Une visite ne peut être programmée plus de 2 mois à l''avance';
    end if;

    # pas le dimanche
    if WeekDay(new.dateEtHeure) = 6 then
        SIGNAL sqlstate '45000' set message_text = 'Une visite ne peut pas se dérouler un dimanche';
    end if;

    # entre 8 et 19 heures
    if time(new.dateEtHeure) not between time('08:00:00') and time('19:00:00') then
        SIGNAL sqlstate '45000' set message_text = 'Une visite doit se situer entre 8 et 19 heures';
    end if;

    # pas de médicaments présentés ni de bilan à la création
    if new.premierMedicament is not null or new.secondMedicament is not null or new.bilan is not null then
        SIGNAL sqlstate '45000' set message_text =
                'le bilan et les médicaments présentés ne peuvent être renseignés lors de la programmation d''une visite';
    end if;
    # au moins deux heures entre chaque visite
    if exists(select 1
              from visite
              where idVisiteur = new.idVisiteur
                and dateEtHeure between new.dateEtHeure - interval 2 hour + interval 1 minute
                  and new.dateEtHeure + interval 2 hour - interval 1 minute) then
        SIGNAL sqlstate '45000' set message_text = 'Il faut au moins deux heures d''écart entre deux visites';
    end if;
    # une seule visite programmée par praticien
    if exists(select 1
              from visite
              where idVisiteur = new.idVisiteur
                and idPraticien = new.idPraticien
                and bilan is null) then
        SIGNAL sqlstate '45000' set message_text = 'Une visite non clôturée existe déjà pour ce praticien';
    end if;
end;

-- ------------------------------------------------------------------------------------------------
-- concernant la modification d'une visite
-- ------------------------------------------------------------------------------------------------

-- première règle
--   trois champs ne sont pas modifiables : id, idPraticien et idVisiteur

-- seconde règle
--    Si la visite est close (bilan déjà renseigné) plus aucun champ ne doit être modifiable  

-- troisième règle : si on arrive ici on sait que la visite n'est pas close dont le bilan non renseigné
--                  Pourquoi ? si c'était le cas la règle deux ne serait pas respectée
-- si la date est modifiée elle doit respecter les 4 règles vues en création :
--    entre 8 et 19 heures hors dimanche, 
--    au plus tard dans les deux mois 
--    séparée d'au moins deux heures de la suivante ou de la précédente
--    au plus tôt dans une heure 

-- 4ème règle

-- si la visite n'est pas encore réalisée  (DateEtHeure > Now) 
--     les champs bilan, premierMedicament et SecondMedicament ne sont pas modifiables (ils doivent rester non renseignés)

-- 
-- sinon (la visite peut être clôurée)
--     Le bilan doit être renseigné si la colonne premierMedicament ou la colonne secondMedicament est renseigné
-- 	   si le bilan est renseigné le premier médicament doit être renseigné et sa valeur doit être différente du second médicament



create trigger avantMajVisite before update on Visite
for each row
begin
#Première règle
	-- Les champs non modifiables
    if new.id != old.id or new.idPraticien != old.idPraticien or new.idVisiteur != old.idVisiteur then
        signal sqlstate '45000'
            set message_text = 'Les champs id, idPraticien et idVisiteur ne sont pas modifiables.';
    end if;

#Deuxième règle
    -- Si la visite est close (bilan déjà renseigné) plus aucun champ ne doit être modifiable
    if old.bilan is not null then
        signal sqlstate '45000'
            set message_text = 'La visite est close et ne peut pas être modifiée.';
    end if;

#Troisième règle
    -- Si la date est modifiée, elle doit respecter les 4 règles : entre 8 et 19 heures hors dimanche, dans les deux mois et séparée d'au moins deux heures de la suivante ou de la précédente
    if new.dateEtHeure != old.dateEtHeure then
        -- La visite doit être entre 8h et 19h hors dimanche
        if hour(new.dateEtHeure) < 8 or hour(new.dateEtHeure) >= 19 or dayofweek(new.dateEtHeure) = 1 then
            signal sqlstate '45000'
                set message_text = 'La date doit être entre 8h et 19h, et hors dimanche.';
        end if;

        -- La date ne doit pas être dans plus de deux mois
        if new.dateEtHeure > now() + interval 2 month then
            signal sqlstate '45000'
                set message_text = 'La date ne peut pas être fixée au-delà de deux mois.';
        end if;

        -- La date doit être séparée d'au moins deux heures des visites précédentes/suivantes
        if exists (
            select 1
            from visite
            where id != new.id
              and abs(timestampdiff(hour, dateEtHeure, new.dateEtHeure)) < 2
        ) then
            signal sqlstate '45000'
                set message_text = 'La date doit être séparée d\'au moins deux heures des autres visites.';
        end if;

        -- La date doit être au plus tôt dans une heure
        if new.dateEtHeure < now() + interval 1 hour then
            signal sqlstate '45000'
                set message_text = 'La date doit être au plus tôt dans une heure.';
        end if;
    end if;


#Quatrième règle
    -- Si la visite n'est pas encore réalisée : (DateEtHeure > Now)
if DateEtHeure > Now() then
   if new.bilan is not null or new.premierMedicament is not null or new.secondMedicament is not null then
       signal sqlstate '45000'
       set message_text = 'Le bilan et les médicaments ne peuvent pas être renseignés avant la réalisation de la visite.';
   end if;
end if;
end;



-- ------------------------------------------------------------------------------------------------
-- concernant l'ajout des échantillons
-- ------------------------------------------------------------------------------------------------

-- L'ajout d'échantillon n'est possible que pour une visite dont le bilan est renseigné
-- dans ce cas le nombre de médicaments distribués ne doit pas dépasser 10
-- on récupère les champs bilan de la visite en les stockant dans des variables
-- si le bilan est null : erreur
-- si déjà 10 échantillons : erreur
-- la quantité doit être supérieure à 0 si elle est renseignée

create trigger avantAjoutEchantillon before insert on Echantillon
for each row
begin

    -- Vérifier si le bilan de la visite est renseigné
    if (select bilan from visite where id = new.idVisite) is null then
        signal sqlstate '45000'
            set message_text = 'Impossible d\'ajouter un échantillon : le bilan de la visite n\'est pas renseigné.';
    end if;

    -- Vérifier le nombre total d'échantillons pour cette visite
    if (select count(*) from echantillon where idVisite = new.idVisite) >= 10 then
        signal sqlstate '45000'
            set message_text = 'Impossible d\'ajouter cet échantillon : le nombre total de médicaments dépasse 10.';
    end if;

    -- Vérifier que la quantité est supérieure à 0
    if new.quantite <= 0 then
        signal sqlstate '45000'
            set message_text = 'La quantité doit être supérieure à 0.';
    end if;
end;

-- ------------------------------------------------------------------------------------------------
-- concernant la modification des échantillons
-- ------------------------------------------------------------------------------------------------

-- les colonnes idVisite et idMedicament ne sont pas modifiables
-- la quantité finale doit resté positive
create trigger avantMajEchantillon before update on Echantillon
for each row
begin


end;








