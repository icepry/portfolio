'use strict';

// Affichage des événements de l'agenda dans des cartes
/* global data */

// création d'une div 'row' de class row
const row = document.createElement('div');
row.classList.add('row');

// parcourir le tableau d'objet data
for (const element of data) {
    // définir une div 'col' utilisant les classes 'col-' afin d'avoir 4 cadres sur un grand écran, 3 sur un lg ou md, 2 sur un sm et 1 en dessous
    const col = document.createElement('div');
    col.classList.add('col-xl-3', 'col-lg-4', 'col-sm-6');

    // définir une div 'carte'
    const carte = document.createElement('div');
    carte.classList.add('card', 'mb-4');

    // définir l'entête qui contient le titre et la date de l'événement
    const entete = document.createElement('div');
    entete.classList.add('card-header', 'bg-dark', 'text-white');

    const titre = document.createElement('h5');
    titre.classList.add('card-title');
    titre.innerText = element.titre;

    const date = document.createElement('h6');
    date.classList.add('card-subtitle', 'mb-2', 'text-white');
    date.innerText = element.date;

    entete.appendChild(titre);
    entete.appendChild(date);

    // définir le corps qui contient le contenu de l'événement
    const corps = document.createElement('div');
    corps.classList.add('card-body');
    corps.innerHTML = element.contenu;

    // assembler les deux éléments composant la carte : entete - corps
    carte.appendChild(entete);
    carte.appendChild(corps);

    // placer la carte dans la colonne
    col.appendChild(carte);

    // placer la colonne dans la ligne
    row.appendChild(col);
}

// intégrer l'ensemble sur l'interface
document.getElementById('lesCartes').appendChild(row);