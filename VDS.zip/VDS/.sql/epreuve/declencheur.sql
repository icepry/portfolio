use ppe;


# contrôle de la saison de la date, de la période d'inscription et de la chronologie de ses trois dates
drop trigger if exists avantAjoutEpreuve;
drop trigger if exists avantModificationEpreuve;

delimiter $$
create trigger avantAjoutEpreuve
    before insert
    on epreuve
    for each row
begin
    # Transformation des chaines vides en NULL
    if new.urlInscription = '' then
        set new.urlInscription = null;
    end if;
    if new.urlInscrit = '' then
        set new.urlInscrit = null;
    end if;
    # contrôle de la colonne id
    if new.id not regexp '^[0-9]+$' or exists (select 1 from epreuve where id = new.id) then
        signal sqlstate '45000' set message_text = '#L''identifiant n''est pas valide';
    end if;
    # contrôle de la colonne description
    if new.description is null then
        signal sqlstate '45000' set message_text = '#La description doit être renseignée';
    end if;
    if new.description regexp
       '<script|drop|select|insert|delete|update|--|\\/\\*|\\*\\/' then
        signal sqlstate '45000' set message_text = '#La description contient des caractères ou des mots interdits. interdits';
    end if;

    # contrôle sur la date
    if new.date is null then
        signal sqlstate '45000' set message_text = '#La date de l''épreuve doit être renseignée';
    end if;
    -- Vérifier si la date est valide : en mode ansi toute valeur erronée est remplacée par la chaine '0000-00-00'
    if new.date regexp '^0000-00-00$' then
        signal sqlstate '45000' set message_text = '#la date n\'est pas valide';
    end if;
    # la date de l'épreuve doit être supérieure à la date du jour
    if new.date < curdate() then
        signal sqlstate '45000' set message_text = '#La date de l''épreuve doit être supérieure à la date du jour';
    end if;
    # contrôle sur la colonne dateOuverture
    if new.dateOuverture is null then
        signal sqlstate '45000' set message_text = '#La date d''ouverture des inscriptions doit être renseignée';
    end if;
    if new.dateOuverture regexp '^0000-00-00$' then
        signal sqlstate '45000' set message_text = '#La date d''ouverture des inscriptions n\'est pas valide';
    end if;

    # contrôle sur la colonne dateFermeture
    if new.dateFermeture is null then
        signal sqlstate '45000' set message_text = '#La date de fermeture des inscriptions doit être renseignée';
    end if;
    if new.dateFermeture regexp '^0000-00-00$' then
        signal sqlstate '45000' set message_text = '#La date de fermeture des inscriptions n\'est pas valide';
    end if;
    # contrôle de la chronologie des dates : dateOuverture < dateFermeture < date
    if new.dateFermeture not between new.dateOuverture and new.date - interval 1 day then
        signal sqlstate '45000' set message_text = '#La période d''inscription n''est pas cohérente';
    end if;

    # contrôle sur la colonne urlInscription
    if new.urlInscription is not null and exists(select 1 from epreuve where urlInscription = new.urlInscription) then
        signal sqlstate '45000' set message_text = '#L''URL d''inscription est déjà utilisée';
    end if;

    # contrôle sur la colonne urlInscrit
    if new.urlInscrit is null and exists(select 1 from epreuve where urlInscrit = new.urlInscrit) then
        signal sqlstate '45000' set message_text = '#L''URL des inscrits est déjà utilisée';
    end if;
end
$$

delimiter $$
create trigger avantModificationEpreuve
    before update
    on epreuve
    for each row
begin
    # Transformation des chaines vides en NULL
    if new.urlInscription = '' then
        set new.urlInscription = null;
    end if;
    if new.urlInscrit = '' then
        set new.urlInscrit = null;
    end if;

    # contrôle de la colonne id
    if new.id != old.id then
        signal sqlstate '45000' set message_text = '#L''identifiant ne peut être modifié';
    end if;

    # contrôle de la description
    if new.description != old.description then
        if (new.description is null or new.description = '') then
            SIGNAL sqlstate '45000' set message_text = '#La description doit être renseignée';
        end if;
        if char_length(new.description) < 10 then
            SIGNAL sqlstate '45000' set message_text = '#La description doit être plus détaillée';
        end if;
        if new.description regexp
           '<script|drop|select|insert|delete|update|--|\\/\\*|\\*\\/' then
            signal sqlstate '45000' set message_text =
                    '#La description contient des caractères ou des mots interdits. interdits';
        end if;
    end if;

    # contrôle de la date
    if new.date is null then
        SIGNAL sqlstate '45000' set message_text = '#La date de l''épreuve doit être renseignée';
    end if;

    # si la date de l'épreuve est modifiée,
    if new.date != old.date then
        # elle doit être valide
        if new.date regexp '^0000-00-00$' then
            SIGNAL sqlstate '45000' set message_text = '#La date de l''épreuve n''est pas valide';
        end if;
        # elle doit être supérieure à la date du jour
        if new.date < curdate() then
            SIGNAL sqlstate '45000' set message_text =
                    '#La date de l''épreuve doit être supérieure à la date du jour';
        end if;
    end if;

    # contrôle de la date d'ouverture
    if new.dateOuverture is null then
        SIGNAL sqlstate '45000' set message_text = '#La date d''ouverture des inscriptions doit être renseignée';
    end if;

    # si la date d'ouverture est modifiée,
    if new.dateOuverture != old.dateOuverture then
        # elle doit être valide
        if new.dateOuverture regexp '^0000-00-00$' then
            SIGNAL sqlstate '45000' set message_text = '#La date d''ouverture des inscriptions n''est pas valide';
        end if;
    end if;

    # contrôle de la date de fermeture
    if new.dateFermeture is null then
        SIGNAL sqlstate '45000' set message_text = '#La date de fermeture des inscriptions doit être renseignée';
    end if;
    # si la date de fermeture est modifiée,
    if new.dateFermeture != old.dateFermeture then
        # elle doit être valide
        if new.dateFermeture regexp '^0000-00-00$' then
            SIGNAL sqlstate '45000' set message_text = '#La date de fermeture des inscriptions n''est pas valide';
        end if;
    end if;


    # contrôle de la période d'inscription
    if new.dateOuverture is null or new.dateFermeture is null then
        SIGNAL sqlstate '45000' set message_text = '#La période d\'inscription n\'est pas indiquée';
    end if;

    # la date de fermeture doit être postérieure à la date d'ouverture
    if new.dateFermeture not between new.dateOuverture + interval 15 day and new.date - interval 1 day then
        SIGNAL sqlstate '45000' set message_text = '#La période d''inscription n''est pas cohérente';
    end if;
end
$$