use ppe;

# test à réaliser avant l'ajout des enrégistrements

# test des valeurs null

# Au niveau du trigger de type before La valeur de NEW.id sera 0. MySQL attribue la valeur réelle de l'autoincrement après l'exécution du trigger BEFORE INSERT.
# il ne faut pas modifier la valeur de la colonne autoincrement dans un trigger BEFORE INSERT, car cela pourrait interférer avec le mécanisme d'autoincrement du SGBD.

# si les 4 épreuves sont déja programmées, on ne peut pas en ajouter une autre et l'erreur renvoyée est :
# [45000][1644] #L'épreuve se situant dans cette saison est déjà programmée

insert into epreuve (description, date, urlInscription, urlInscrit, dateOuverture, dateFermeture)
values (null, '2025-02-02', 'url', 'url', '2025-01-01', '2025-02-01');
# [45000][1644] #La description doit être renseignée

insert into epreuve (description, date, urlInscription, urlInscrit, dateOuverture, dateFermeture)
values ('description', null, 'url', 'url', '2025-01-01', '2025-02-01');
# [45000][1644] #La date de l'épreuve doit être renseignée

insert into epreuve (description, date, urlInscription, urlInscrit, dateOuverture, dateFermeture)
values ('description', '2025-02-02',  'url' , 'url', null, '2025-02-01');
# [45000][1644] #La date d'ouverture des inscriptions doit être renseignée

insert into epreuve (description, date, urlInscription, urlInscrit, dateOuverture, dateFermeture)
values ('description', '2025-02-02',  'url' , 'url', '2025-01-01', null);
#[45000][1644] #La date de fermeture des inscriptions doit être renseignée

-- test des valeurs vides

set sql_mode='traditional,only_full_group_by';
insert into epreuve (description, date, urlInscription, urlInscrit, dateOuverture, dateFermeture)
values ('description', '', '', '', '', '');
# en mode traditional : [HY000][1366] Incorrect integer value: '' for column 'id' at row 1

set sql_mode = 'ansi';
insert into epreuve (description, date, urlInscription, urlInscrit, dateOuverture, dateFermeture)
values ('description', '', '', '', '', '');
#en mode ansi [45000][1644] #L'épreuve se situant dans cette saison est déjà programmée
# en mode ansi si l'épreuve sur la saison n'existe pas : [45000][1644] #la date n'est pas valide

-- test des valeurs erronées
set sql_mode='traditional,only_full_group_by';
insert into epreuve (description, date, urlInscription, urlInscrit, dateOuverture, dateFermeture)
values ('description', '2024-11-43', 'url', 'url', '', '');
# en mode traditional : [HY000][1366] Incorrect integer value: '2024-11-43' for column 'date' at row 1

set sql_mode = 'ansi';
insert into epreuve (description, date, urlInscription, urlInscrit, dateOuverture, dateFermeture)
values ('description', '', '', '', '', '');
# en mode ansi [45000][1644] #la date n'est pas valide

insert into epreuve (description, date, urlInscription, urlInscrit, dateOuverture, dateFermeture)
values ('description', '2024-05-23', 'url', 'url', '', '');
# [45000][1644] #La date de l'épreuve doit être supérieure à la date du jour1


insert into epreuve (description, date, urlInscription, urlInscrit, dateOuverture, dateFermeture)
values ('description', curdate() + interval 2 month, 'url', 'url', curdate() + interval 1 day, curdate()) ;
# [45000][1644] #La période d'inscription n'est pas cohérente

-- une saison erronée
insert into epreuve (description, date, urlInscription, urlInscrit, dateOuverture, dateFermeture)
values ( 'description', '2024-11-43', 'url', 'url', '2024-09-02', '2024-10-31');
# [45000][1644] #La saison doit être correctement renseignée

-- une date d'ouverture erronée
set sql_mode='traditional,only_full_group_by';
insert into epreuve (description, date, urlInscription, urlInscrit, dateOuverture, dateFermeture)
values ('description', '2024-11-03', 'url', 'url', '2024-09-31', '2024-10-31');
# en mode traditional : [HY000][1366] Incorrect integer value: '2024-09-31' for column 'dateOuverture' at row 1

set sql_mode = 'ansi';
insert into epreuve (description, date, urlInscription, urlInscrit, dateOuverture, dateFermeture)
values ('description', '2024-11-03', 'url', 'url', '2024-09-31', '2024-10-31');
# EN MODE ANSI [45000][1644] #La date d'ouverture des inscriptions n`'est pas valide

-- une date de fermeture erronée
set sql_mode='traditional,only_full_group_by';
insert into epreuve (id,  description, date, urlInscription, urlInscrit, dateOuverture, dateFermeture)
values (5, 'description', '2025-02-15', 'url', 'url', '2025-09-02', '2025-02-31');
# en mode traditional : [HY000][1366] Incorrect integer value: '2025-02-31' for column 'dateFermeture' at row 1

set sql_mode = 'ansi';
insert into epreuve (id,  description, date, urlInscription, urlInscrit, dateOuverture, dateFermeture)
values (5,  'description', '2025-02-15', 'url', 'url', '2025-09-02', '2025-02-31');
# en mode ansi [[45000][1644] #La date de fermeture des inscriptions n`'est pas valide

-- une date déjà passée
insert into epreuve (id,  description, date, urlInscription, urlInscrit, dateOuverture, dateFermeture)
values (5,  'description', '2024-04-15', 'url', 'url', '2024-01-02', '2024-02-20');
#[45000][1644] #La date de l'épreuve doit être supérieure à la date du jour

-- une description avec injection
insert into epreuve (id,  description, date, urlInscription, urlInscrit, dateOuverture, dateFermeture)
values (5, 'test<script>alert(1);</script>test', curdate() + interval 2 month, 'url', 'url', curdate() + interval 1 day, curdate() + interval 1 month);
# [45000][1644] #La description contient des caractères ou des mots interdits. interdits

-- controle d'unicité

delete from epreuve;

insert into epreuve (description, date, dateOuverture, dateFermeture, urlInscription)
values ('description', curdate() + interval 2 month, curdate() + interval 1 day, curdate() + interval 1 month, 'url');
select * from epreuve;

insert into epreuve (description, date, dateOuverture, dateFermeture)
values ('description', curdate() + interval 2 month, curdate() + interval 1 day, curdate() + interval 1 month);
# [45000][1644] #L'épreuve se situant dans cette saison est déjà programmée

insert into epreuve (description, date, dateOuverture, dateFermeture)
values ('description', curdate() + interval 2 month, curdate() + interval 1 day, curdate() + interval 1 month);
# [45000][1644] #Une épreuve est déjà programmée à cette date

insert into epreuve (description, date, urlInscription, dateOuverture, dateFermeture)
values ('description', curdate() + interval 3 month, 'url', curdate() + interval 1 day, curdate() + interval 1 month);
# [45000][1644] #L'URL d'inscription est déjà utilisée

-- Test sur la modification

-- IMPORTANT : il faut exécuter le script insert.sql avant de tester les modifications

select * from epreuve;

update epreuve set id = 5 where id = 2;
# [45000][1644] #L'identifiant ne peut être modifié

update epreuve set id = null;
# [23000][1048] Le champ 'id' ne peut être vide (null)


update epreuve set date = null;
# [45000][1644] #La date de l'épreuve doit être renseignée

update epreuve set dateOuverture = null;
# [[45000][1644] #La date d'ouverture des inscriptions doit être renseignée

update epreuve set dateFermeture = null;
# [45000][1644] #La date de fermeture des inscriptions doit être renseignée


-- valeur erronée
set sql_mode='traditional,only_full_group_by';
update epreuve set date = '2025-02-29';
# [22001][1292] Data truncation: Incorrect date value: '2025-02-29' for column 'date' at row 1


set sql_mode='ansi';
update epreuve set date = '2025-02-29';
# [45000][1644] #La date de l'épreuve n`'est pas valide

set sql_mode='traditional,only_full_group_by';
update epreuve set dateOuverture = '2025-02-29';
# [22001][1292] Data truncation: Incorrect date value: '2025-02-29' for column 'dateOuverture' at row 1

set sql_mode='ansi';
update epreuve set dateOuverture = '2025-02-29';
# [45000][1644] #La date d'ouverture des inscriptions n`'est pas valide



set sql_mode='traditional,only_full_group_by';
update epreuve set dateFermeture = '2025-02-29';
# [22001][1292] Data truncation: Incorrect date value: '2025-02-29' for column 'dateFermeture' at row 1

set sql_mode='ansi';
update epreuve set dateFermeture = '2025-02-29';
# [45000][1644] #La date de fermeture des inscriptions n`'est pas valide

update epreuve set dateOuverture = dateFermeture + interval 1 day;
# [45000][1644] #La période d'inscription n'est pas cohérente

select * from epreuve;
