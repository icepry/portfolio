set @@sql_mode='ansi';
# Rappel En mode ANSI (ou mode souple) les valeurs invalides sont remplacées par des valeurs acceptables : une date invalide devient ‘0000-00-00’
# En mode TRADITIONAL (ou mode strict) les valeurs invalides génèrent une erreur et l’opération est refusée avant même que les triggers de type before ne soient lancées.

delete from epreuve;

insert into epreuve (id, description, date, urlInscription, urlInscrit, dateOuverture,
                     dateFermeture)
values (1,
        '<p><strong>Label r&eacute;gional FFA qualificatif au championnat de France sur l&#39;ensemble des courses</strong></p>\n\n<p>Les Courses</p>\n\n<ul>\n	<li>5 km d&eacute;couverte: 9H20&nbsp;</li>\n	<li>10 km Course des Joggers: 10H05&nbsp;</li>\n	<li>10 km Course des As: 11H20&nbsp;</li>\n</ul>\n\n<p>Le tarif qui vous donne droit le droit de&nbsp;participer &agrave; l&#39;ensemble des courses.</p>\n\n<ul>\n	<li>Licenci&eacute;s FFA&nbsp; &nbsp; &nbsp; &nbsp;: 8&nbsp;euros&nbsp;</li>\n	<li>Non licenci&eacute;s FFA : 10&nbsp;euros&nbsp;</li>\n	<li>Gratuit&eacute; pour les membres de l&#39;Amicale du val de Somme</li>\n</ul>\n',
        '2025-03-02', null, null, '2025-01-01', '2025-02-27'),
       (2,
        '<p>Les Courses</p>\n\n<ul>\n	<li>5 km d&eacute;couverte: 9H20&nbsp;</li>\n	<li>10 km Course des Joggers: 10H05&nbsp;</li>\n	<li>10 km Course des As: 11H20&nbsp;</li>\n</ul>\n\n<p>Le tarif qui vous donne droit le droit de&nbsp;participer &agrave; l&#39;ensemble des courses.</p>\n\n<ul>\n	<li>Licenci&eacute;s FFA&nbsp; &nbsp; &nbsp; &nbsp;: 6 euros&nbsp;</li>\n	<li>Non licenci&eacute;s FFA : 8 euros&nbsp;</li>\n	<li>Gratuit&eacute; pour les membres de l&#39;Amicale du val de Somme</li>\n</ul>\n',
        '2025-04-27', null, null, '2025-03-03', '2025-04-24'),
       (3,
        '<p>Les Courses</p>\n\n<ul>\n	<li>5 km d&eacute;couverte: 9H20&nbsp;</li>\n	<li>10 km Course des Joggers: 10H05&nbsp;</li>\n	<li>10 km Course des As: 11H20&nbsp;</li>\n</ul>\n\n<p>Le tarif qui vous donne droit le droit de&nbsp;participer &agrave; l&#39;ensemble des courses.</p>\n\n<ul>\n	<li>Licenci&eacute;s FFA&nbsp; &nbsp; &nbsp; &nbsp;: 6 euros&nbsp;</li>\n	<li>Non licenci&eacute;s FFA : 8 euros&nbsp;</li>\n	<li>Gratuit&eacute; pour les membres de l&#39;Amicale du val de Somme</li>\n</ul>\n',
        '2025-09-07', null, null, '2025-07-01', '2025-09-04'),
       (4,
        '<p><strong>Label r&eacute;gional FFA qualificatif au championnat de France sur l&#39;ensemble des courses</strong></p>\n\n<p>Pour cette finale, plus de 2000 &euro; de prime seront distribu&eacute;s et un lot de grande qualit&eacute; sera offert &agrave; chaque arrivant.</p>\n\n<p>Les Courses</p>\n\n<ul>\n	<li>5 km d&eacute;couverte: 9H20&nbsp;</li>\n	<li>10 km Course des Joggers: 10H05&nbsp;</li>\n	<li>10 km Course des As: 11H20&nbsp;</li>\n</ul>\n\n<p>Le tarif qui vous donne droit le droit de&nbsp;participer &agrave; l&#39;ensemble des courses.</p>\n\n<ul>\n	<li>Licenci&eacute;s FFA&nbsp; &nbsp; &nbsp; &nbsp;: 8&nbsp;euros&nbsp;</li>\n	<li>Non licenci&eacute;s FFA : 10&nbsp;euros&nbsp;</li>\n	<li>Gratuit&eacute; pour les membres de l&#39;Amicale du val de Somme</li>\n</ul>\n',
        '2024-11-03',
        'https://www.klikego.com/inscription/finale-des-quatre-saisons-5-et-10-km-2024/course-a-pied-running/1603054434896-21',
        'https://www.klikego.com/inscrits/finale-des-quatre-saisons-5-et-10-km-2024/1603054434896-21', '2024-09-02',
        '2024-10-31');


