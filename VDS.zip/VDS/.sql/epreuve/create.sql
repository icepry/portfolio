use ppe;

SET default_storage_engine = InnoDb;

drop table if exists epreuve;

create table epreuve (
  id int(11) not null auto_increment primary key ,
  description text not null,
  date date not null,
  urlInscription varchar(150)  null ,
  urlInscrit varchar(150)  null ,
  dateOuverture date not null ,
  dateFermeture date not null
);

