# D�placement � la racine du site
Set-Location ..

Write-Host "Basculer sur la branche main locale" -ForegroundColor Cyan
git checkout main

Write-Host "R�cup�rer les modifications de la branche main distante" -ForegroundColor Cyan
git fetch origin
git reset --hard origin/main


