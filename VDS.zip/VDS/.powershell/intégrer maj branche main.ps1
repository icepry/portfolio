# D�placement � la racine du site
Set-Location ..

# Obtenir le nom de la branche actuelle
$branche = git rev-parse --abbrev-ref HEAD

# La branche active ne doit pas �tre la branche main
if ($branche -eq "main") {
    Write-Host "Veuillez basculer sur votre branche de travail pour ex�cuter ce script." -ForegroundColor Red
    exit 1
}

Write-Host "Fusionner la branche main dans la branche $branche" -ForegroundColor Cyan
git merge main --allow-unrelated-histories
