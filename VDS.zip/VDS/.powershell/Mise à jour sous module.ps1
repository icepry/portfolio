# D�placement � la racine du site
Set-Location ..

# D�finition du tableau de sous-modules
$submodules = @(
    @{
        Name = "classetechnique"
        Url = "https://github.com/verghote/classetechnique.git"
    },
    @{
        Name = "erreur"
        Url = "https://github.com/verghote/erreur.git"
    }
)

# It�ration sur chaque sous-module
foreach ($submodule in $submodules) {
    $name = $submodule.Name
    $url = $submodule.Url

    if (Test-Path -Path $name) {
        git submodule deinit -f -- $name
        git rm -f $name
        Remove-Item -Recurse -Force ".git/modules/$name" -ErrorAction SilentlyContinue
    }

    # Initialiser et mettre � jour le sous-module
    Write-Host "Initialiser et mettre � jour le sous-module $name" -ForegroundColor Cyan
    git submodule add $url

    # Afficher un message de confirmation
    Write-Host "Le sous-module $name a �t� ajout� avec succ�s." -ForegroundColor Green
}