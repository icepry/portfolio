<a style="text-decoration: none; color: white; font-size:1.2em; padding-left: 10px"
   href="/mentionslegales">
    Mentions légales
</a>
<a style="text-decoration: none; color: white; font-size:1.2em; padding-left: 10px"
   class="text-left"
   href="/politique">
    Politique de confidentialité
</a>
