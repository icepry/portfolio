﻿"use strict";

import {
    verifier,
    afficherErreur,
    fichierValide,
    confirmer, afficherErreurSaisie, afficherSucces
} from "https://verghote.github.io/composant/fonction.js";

// variable globale
/* global lesPartenaires, lesParametres, token */

// id du partenaire en cours de modification
let idPartenaire;

// conserver le nom du fichier à remplacer
let nomFichier;

const listePartenaires = document.getElementById('listePartenaires');
const fichier = document.getElementById('fichier');

// traitement du champ file associé aux modifications des logos
fichier.onchange = function () {
    if (this.files.length > 0) {
        controlerFichier(this.files[0]);
    }
};

afficher();

/**
 * Affichage des coordonées des parteneaires et de leur logo dans des cadres
 * Utilisation de balises input pour permettre la modification des coordonnées
 */
function afficher() {
    listePartenaires.innerHTML = '';
    const row = document.createElement('div');
    row.classList.add('row');
    for (const partenaire of lesPartenaires) {
        const id = partenaire.id;
        const col = document.createElement('div');
        col.classList.add('col-xl-4', 'col-lg-6', 'col-md-6', 'col-sm-12', 'col-12');
        const carte = document.createElement('div');
        carte.id = id;
        carte.classList.add('card', 'mb-3');

        // génération de l'entête : une icône pour supprimer le partenaire
        const entete = document.createElement('div');
        entete.classList.add('card-header', 'bg-text-center', 'd-flex', 'justify-content-around');
        // ajout de l'icône de suppression en haut à droite du cadre
        let i = document.createElement('i');
        i.classList.add('bi', 'bi-x', 'text-danger', 'float-end', 'fs-2');
        i.title = 'Supprimer  le partenaire';
        i.onclick = () => confirmer(() => supprimer(partenaire.id));
        entete.appendChild(i);


        carte.appendChild(entete);

        // génération du corps de la carte : comprenant 2 balises input pour le nom et l'url
        const corps = document.createElement('div');
        corps.classList.add('card-body', 'p-3', 'd-flex', 'flex-column', 'align-items-center');

        // ajout d'une balise input pour la modification du nom
        const inputNom = document.createElement('input');
        inputNom.classList.add('form-control');
        inputNom.type = 'text';
        inputNom.value = partenaire.nom;
        inputNom.dataset.old = partenaire.nom;
        inputNom.pattern = '^[0-9A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÒÓÔÕÖÙÚÛÜÝàáâãäåçèéêëìíîïðòóôõöùúûüýÿ](?:[\' \\-]?[0-9A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÒÓÔÕÖÙÚÛÜÝàáâãäåçèéêëìíîïðòóôõöùúûüýÿ])*$';
        inputNom.maxlength = 20;
        inputNom.onchange = function () {
            this.value = this.value.replace(/\s{2,}/, ' ').trim();
            if (this.value !== this.dataset.old && verifier(this)) {
                modifierColonne('nom', this, partenaire.id);
            }
        };
        corps.appendChild(inputNom);

        // ajout d'uine balise imput pour la modification de l'url
        const inputUrl = document.createElement('input');
        inputUrl.classList.add('form-control', "mt-2");
        inputUrl.type = 'url';
        inputUrl.value = partenaire.url;
        inputUrl.dataset.old = partenaire.url;
        inputUrl.onchange = function () {
            if (this.value !== this.dataset.old && verifier(this)) {
                modifierColonne('url', this, partenaire.id);
            }
        };
        corps.appendChild(inputUrl);

        // Ajout de la zone d'upload
        let div = document.createElement('div');
        div.id = 'photo' + id;
        div.classList.add('upload');
        div.style.width = '200px';
        div.style.weight = '200px';
        // Si la photo existe on la place dans la zone
        if (partenaire.present) {
            const img = document.createElement('img');
            img.src = lesParametres.repertoire + '/' + partenaire.fichier;
            img.alt = '';
            div.appendChild(img);
        }
        // définition des événements pour gérer le téléversement et le glisser déposer
        div.onclick = function () {
            idPartenaire = id;
            fichier.click();
        };
        div.ondragover = function (e) {
            e.preventDefault();
        };
        div.ondrop = function (e) {
            idPartenaire = id;
            e.preventDefault();
            controlerFichier(e.dataTransfer.files[0]);
        };
        corps.appendChild(div);
        carte.appendChild(corps);
        col.appendChild(carte);
        row.appendChild(col);
        listePartenaires.appendChild(row);
    }
}

function modifierColonne(colonne, input, id) {
    $.ajax({
        url: '/ajax/modifiercolonne.php',
        method: 'post',
        data: {
            table : 'partenaire',
            colonne: colonne,
            valeur: input.value,
            id: id,
            token: token
        },
        dataType: 'json',
        success: data => {
            if (data.success) {
                input.dataset.old = input.value;
                input.style.color = 'green';
            } else if (data.error) {
                for (const key in data.error) {
                    const message = data.error[key];
                    if (key === 'system') {
                        afficherErreur("Erreur système détectée, contacter l'administrateur du site");
                    } else if (key === 'global') {
                        afficherErreur(message);
                    } else {
                        afficherErreurSaisie(key, message);
                    }
                }
            }
        },
        error: reponse => {
            afficherErreur('Une erreur imprévue est survenue');
            console.log(reponse.responseText);
        }
    });

}

/**
 * Suppression du partenaire dans la table partenaire et suppression du fichier associé dans le répertoire data/partenaire
 * @param id  identifiant du partenaire à supprimer
 */
function supprimer(id) {
    $.ajax({
        url: '/ajax/supprimer.php',
        method: 'POST',
        data: {
            table: 'partenaire',
            id: id,
            token: token
        },
        dataType: 'json',
        success: data => {
            if (data.success) {
                // Mise à jour de l'interface : on retire le partenaire dans la liste et on relance l'affichage
                lesPartenaires.splice(lesPartenaires.findIndex(x => x.id === id), 1);
                afficher();
            } else if (data.error) {
                for (const key in data.error) {
                    const message = data.error[key];
                    if (key === 'system') {
                        afficherErreur("Erreur système détectée, contacter l'administrateur du site");
                    } else if (key === 'global') {
                        afficherErreur(message);
                    } else {
                        afficherErreurSaisie(key, message);
                    }
                }
            }
        },
        error: reponse => {
            afficherErreur('Une erreur imprévue est survenue');
            console.log(reponse.responseText);
        }
    });
}


function controlerFichier(file) {
    // définition des contraintes sur le fichier téléversé
    const controle = {
        taille: lesParametres.maxSize,
        lesExtensions: lesParametres.extensions,
    };
    if (!fichierValide(file, controle)) {
        afficherErreur(controle.reponse);
        return false;
    }
    // vérification des dimensions
    // création d'un objet image
    let img = new Image();
    // chargement de l'image
    img.src = window.URL.createObjectURL(file);
    // il faut attendre que l'image soit chargée pour effectuer les contrôles
    img.onload = function () {
        if (img.width > lesParametres.width || img.height > lesParametres.height) {
            let msg = "Les dimensions de l'image (" + img.width + " * " + img.height + ") dépassent les dimensions autorisées (" + lesParametres.width + " * " + lesParametres.height + ")";
            afficherErreur(msg);
            return false;
        } else {
            remplacer(file, img);
        }
    };
    // si l'image n'est pas chargée (cas d'un fichier non image)
    img.onerror = function () {
        afficherErreur("Il ne s'agit pas d'un fichier image");
    };
}

/**
 * @param   {object} file objet de type file contenant l'image à contrôler
 * @param   {object} img objet de type image contenant l'image à afficher
 */
function remplacer(file, img) {
    const monFormulaire = new FormData();
    monFormulaire.append('fichier', file);
    monFormulaire.append('id', idPartenaire);
    monFormulaire.append('token', token);
    $.ajax({
        url: 'photo/remplacer.php',
        type: 'POST',
        data: monFormulaire,
        processData: false,
        contentType: false,
        dataType: 'json',
        success: function (data) {
            if (data.success) {
                // on place la nouvelle photo dans le cadre cible correspondant
                const cible = document.getElementById('photo' + idPartenaire);
                cible.innerHTML = '';
                cible.appendChild(img);
            } else if (data.error) {
                for (const key in data.error) {
                    const message = data.error[key];
                    if (key === 'system') {
                        afficherErreur("Erreur système détectée, contacter l'administrateur du site");
                    } else if (key === 'global') {
                        afficherErreur(message);
                    } else {
                        afficherErreurSaisie(key, message);
                    }
                }
            }
        },
        error: (reponse) => {
            console.log(reponse.responseText);
        }
    });
}




