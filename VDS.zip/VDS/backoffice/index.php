<?php
declare(strict_types=1);
// activation du chargement dynamique des ressources
require $_SERVER['DOCUMENT_ROOT'] . "/include/autoload.php";



// chargement des données


// chargement de l'interface
require RACINE . "/backoffice/include/interface.php";