<?php
header('HTTP/1.0 401 Unauthorized');
?>
<meta http-equiv="refresh" content="0;url=/">
