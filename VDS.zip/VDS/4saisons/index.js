"use strict";
/* global data */

document.getElementById('contenu').innerHTML = data.contenu;
