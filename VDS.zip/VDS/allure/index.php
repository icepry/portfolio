<?php
// activation du chargement dynamique des ressources
require $_SERVER['DOCUMENT_ROOT'] . "/include/autoload.php";

// chargement des données

// chargement de l'interface
require RACINE . "/include/interface.php";


