<?php
// liste des journaux utilisés dans l'application
return [
    'erreur' => 'Journal des erreurs'
];